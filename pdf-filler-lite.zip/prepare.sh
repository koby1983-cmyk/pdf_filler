#!/bin/bash
# copies the libraries, fonts and OCR files from node_modules into www/
set -e
N=node_modules
mkdir -p www/lib www/fonts www/ocr/core www/ocr/lang
cp $N/pdfjs-dist/build/pdf.min.js $N/pdfjs-dist/build/pdf.worker.min.js www/lib/
cp $N/pdf-lib/dist/pdf-lib.min.js www/lib/
for s in hebrew cyrillic latin; do for w in 400 700; do cp $N/@fontsource/arimo/files/arimo-$s-$w-normal.woff2 www/fonts/; done; done
for s in hebrew latin; do for w in 400 500 700; do cp $N/@fontsource/heebo/files/heebo-$s-$w-normal.woff2 www/fonts/; done; done
cp $N/tesseract.js/dist/tesseract.min.js $N/tesseract.js/dist/worker.min.js www/ocr/
cp $N/tesseract.js-core/tesseract-core-lstm.wasm.js $N/tesseract.js-core/tesseract-core-simd-lstm.wasm.js $N/tesseract.js-core/tesseract-core-relaxedsimd-lstm.wasm.js www/ocr/core/
for l in heb rus eng; do cp $N/@tesseract.js-data/$l/4.0.0_best_int/$l.traineddata.gz www/ocr/lang/; done
find www -type f | sort
