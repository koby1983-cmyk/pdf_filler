#!/bin/bash
# runs automatically after "cap sync": adds the app's own native code to the Android project
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="${CAPACITOR_ROOT_DIR:-.}/android/app/src/main/java/com/koby/pdffiller"
if [ -d "$DEST" ]; then
  cp "$DIR/SaveAsPlugin.java" "$DIR/MainActivity.java" "$DEST/"
  echo "native: SaveAs plugin installed"
fi
