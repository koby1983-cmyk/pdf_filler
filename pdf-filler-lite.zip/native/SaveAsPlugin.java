package com.koby.pdffiller;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Base64;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** "Save as" with Android's own file picker: the user chooses the folder and the file name. */
@CapacitorPlugin(name = "SaveAs")
public class SaveAsPlugin extends Plugin {

    @PluginMethod
    public void save(PluginCall call) {
        String name = call.getString("filename", "document.pdf");
        String mime = call.getString("mime", "application/pdf");
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, intent, "onSaveResult");
    }

    @ActivityCallback
    private void onSaveResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("cancelled", "CANCELLED");
            return;
        }
        Uri uri = data.getData();
        long written = 0;
        OutputStream os = null;
        InputStream in = null;
        try {
            os = getContext().getContentResolver().openOutputStream(uri, "w");
            if (os == null) throw new Exception("no output stream");
            String src = call.getString("source", null);
            if (src == null || src.length() == 0) src = call.getString("path", null);
            if (src != null && src.length() > 0) {
                // copy from the temporary file the page wrote (no big data passes through the bridge)
                in = getContext().getContentResolver().openInputStream(Uri.parse(src));
                if (in == null) throw new Exception("cannot read " + src);
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    os.write(buf, 0, n);
                    written += n;
                }
            } else {
                byte[] bytes = Base64.decode(call.getString("data", ""), Base64.DEFAULT);
                os.write(bytes);
                written = bytes.length;
            }
            os.flush();
        } catch (Throwable e) {
            close(in);
            close(os);
            call.reject("write failed: " + e, "WRITE_FAILED");
            return;
        }
        close(in);
        close(os);
        if (written == 0) {
            call.reject("nothing was written", "EMPTY");
            return;
        }
        JSObject ret = new JSObject();
        ret.put("uri", uri.toString());
        ret.put("name", displayName(uri));
        ret.put("bytes", String.valueOf(written));
        call.resolve(ret);
    }

    private static void close(java.io.Closeable c) {
        if (c == null) return;
        try {
            c.close();
        } catch (Exception ignored) {
        }
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    @PluginMethod
    public void open(PluginCall call) {
        try {
            Uri uri = Uri.parse(call.getString("uri", ""));
            Intent view = new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri, call.getString("mime", "application/pdf"));
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(view, "פתח את הקובץ");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("open failed: " + e.getMessage(), "OPEN_FAILED");
        }
    }
}
